<?php
echo 1;
include 'config.php';
include 'fileclass.php';
echo FILENAME;
$a = new Fileclass(FILENAME);
echo 3;
echo $a->getRow(3);

?>
