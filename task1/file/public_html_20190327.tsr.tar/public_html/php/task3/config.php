<?php
define("FILENAME","file.txt");
?> 
