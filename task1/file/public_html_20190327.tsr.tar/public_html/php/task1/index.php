<?php
    include 'config.php';
    include 'function.php';
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
       $rez_upload = my_uploadfile();
    } else  if ($_SERVER['REQUEST_METHOD'] === 'GET') {
             $rez_del = del_file();   
           }
 
    $tab_file = viewdir();

    include 'templates/index.php';

?>
