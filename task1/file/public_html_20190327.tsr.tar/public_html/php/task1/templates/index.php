<?php
    include 'config.php';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>file meneger</title>
</head>
<body>
   <form enctype="multipart/form-data" action="" method="POST">
       <input type="hidden" name="MAX_FILE_SIZE" value="<?=MAXSIZE?>" />
       Send file <input name="inputfile" type="file" />
       <input type="submit" value="Send file" />
   </form>  
   <?php
      echo $rez_upload;
      echo $rez_del;
   ?>
   <table border='1'>
   <tr>
    <th>N</th> <th>File name</th> <th>Size</th> <th>Delete</th>  </tr>
   <?php
    $i=1;
    foreach ( $tab_file as $value ) {
   ?>
        <tr>
        <td><?=$i?></td>
        <td><?=$value["name"]?></td> 
        <td><?=$value["size"]?></td>
        <td> <a href='?file=<?=$value["name"]?>' > Del </a> </td>
        </tr>
    <?php
        $i++;
     }
    ?>
   
   </table>
  
 </body>
</html>
