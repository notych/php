<?php
define("FILEDIR" , __DIR__ . DIRECTORY_SEPARATOR ."file".DIRECTORY_SEPARATOR); 
define("MAXSIZE" , "300000");
?>
