<?php
include 'config.php';

function my_uploadfile(){
    if(isset($_FILES) && $_FILES['inputfile']['error'] == 0){
        if(is_uploaded_file( $_FILES['inputfile']['tmp_name'])){ 
            $destiation_dir =  FILEDIR.$_FILES['inputfile']['name'];  // ??
            if(move_uploaded_file($_FILES['inputfile']['tmp_name'], $destiation_dir )){
                return 'File Uploaded';
            } else {
                return "No move upload file. Permissions " . FILEDIR. "(" . fileperms(FILEDIR).")";  
            }
        }
     } else{
       switch ($_FILES['inputfile']['error'])  {
         case 1:
           $e = "UPLOAD_ERR_INI_SIZE";
         break;
         case 2:
           $e= "UPLOAD_ERR_FORM_SIZE";
         break;
         case 3:
            $e = "UPLOAD_ERR_PARTIAL";
         break;
         case 4:
            $e = "UPLOAD_ERR_NO_FILE";
         break;
        } 
      return "No File Uploaded " . $e;
     }
   }

function formatBytes($bytes, $precision = 2) { 
    $units = array('B', 'KB', 'MB', 'GB', 'TB'); 
    $bytes = max($bytes, 0); 
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024)); 
    $pow = min($pow, count($units) - 1); 
    return round($bytes, $precision) . ' ' . $units[$pow]; 
}  

function viewdir(){
    $result = array();
    $cdir = scandir(FILEDIR); // ??
    $i = 0;
    foreach ($cdir as $value) {
        if (!in_array($value,array(".", "..")) && !is_dir($value)) {
            $result[$i]['name'] = $value;
            $result[$i]['size'] = formatBytes( filesize( FILEDIR . $value ));
            $i++;
        }
    } 
    return $result;       
}

function del_file(){
    if(isset($_GET["file"]) && !empty($_GET["file"])){
       // ???
       if(!unlink(FILEDIR.$_GET["file"])){
           return "No delete file. Permissions " . FILEDIR . $_GET["file"]. "(" . fileperms( FILEDIR. $_GET["file"]) . ")";  
       } 
    }
}  		

?>
