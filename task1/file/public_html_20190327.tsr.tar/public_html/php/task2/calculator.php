<?php
class Calculator {
    protected $a;
    protected $b;
    function __construct1($a, $b){
        $this->setA($a);
        $this->setB($b);
    }
    function setA($a){
       $this->a = $a; 
    }
    function getA(){
       return $this->a;  
    }
     function setB($b){
       $this->b = $b; 
    }
    function getB(){
       return $this->B;  
    }
    function add(){
        return $this->a + $this->b;
    }
    function sub(){
        return $this->a - $this->b;
    }
    function mult(){
        return $this->a * $this->b;
    }
    function divi() {
       if ($this->b != 0) { 
           return $this->a/$this->b;
       } else {
         return "Divide 0 !!!";
       }
    }
function str_op($oprator)
    {
        switch($oprator)
        {
            case '+':
            return $this->add();
            break;

            case '-':
            return $this->sub();
            break;

            case '*':
            return $this->must();
            break;

            case '/':
            return $this->divi();
            break;

            default:
            return "Sorry No command found";
        }   
    }

}
