<?php
include 'calculator.php';
    $cal = new Calculator;
    $cal->setA(3);
    $cal->setB(4);
    echo $cal->add();
    echo $cal->divi();
?>
